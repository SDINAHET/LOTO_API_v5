
// package com.fdjloto.api.dto;

// import com.fdjloto.api.TestDataFactory;
// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class LotoResultDTOTest {
// @Test void defaultConstructor_createsInstance() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_02() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_03() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             LotoResultDTO obj = new LotoResultDTO();
//             assertNotNull(obj);
//         }
// }
