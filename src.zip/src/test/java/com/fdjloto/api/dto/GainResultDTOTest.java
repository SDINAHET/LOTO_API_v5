
// package com.fdjloto.api.dto;

// import com.fdjloto.api.TestDataFactory;
// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class GainResultDTOTest {
// @Test void defaultConstructor_createsInstance() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_02() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_03() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             GainResultDTO obj = new GainResultDTO();
//             assertNotNull(obj);
//         }
// }
