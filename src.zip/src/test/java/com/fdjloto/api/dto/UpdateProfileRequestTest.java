
// package com.fdjloto.api.dto;

// import com.fdjloto.api.TestDataFactory;
// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class UpdateProfileRequestTest {
// @Test void defaultConstructor_createsInstance() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_02() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_03() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             UpdateProfileRequest obj = new UpdateProfileRequest();
//             assertNotNull(obj);
//         }
// }
