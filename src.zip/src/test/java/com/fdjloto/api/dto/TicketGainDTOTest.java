
// package com.fdjloto.api.dto;

// import com.fdjloto.api.TestDataFactory;
// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class TicketGainDTOTest {
// @Test void defaultConstructor_createsInstance() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_02() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_03() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             TicketGainDTO obj = new TicketGainDTO();
//             assertNotNull(obj);
//         }
// }
