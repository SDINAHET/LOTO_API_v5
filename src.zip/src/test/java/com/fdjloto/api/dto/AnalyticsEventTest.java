
// package com.fdjloto.api.dto;

// import com.fdjloto.api.TestDataFactory;
// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class AnalyticsEventTest {
// @Test void defaultConstructor_createsInstance() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_02() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_03() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             AnalyticsEvent obj = new AnalyticsEvent();
//             assertNotNull(obj);
//         }
// }
