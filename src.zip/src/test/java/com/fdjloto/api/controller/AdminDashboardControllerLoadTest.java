package com.fdjloto.api.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AdminDashboardControllerLoadTest {
@Test void classLoads_01() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_02() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_03() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_04() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_05() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_06() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_07() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_08() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_09() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
@Test void classLoads_10() {
            assertDoesNotThrow(() -> Class.forName("com.fdjloto.api.controller.AdminDashboardController"));
        }
}
