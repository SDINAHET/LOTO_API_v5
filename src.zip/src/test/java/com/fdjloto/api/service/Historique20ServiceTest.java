package com.fdjloto.api.service;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import com.fdjloto.api.repository.Historique20Repository;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(org.mockito.junit.jupiter.MockitoExtension.class)
class Historique20ServiceTest {
    @Mock Historique20Repository historique20Repository;

    @InjectMocks Historique20Service service;

@Test void smoke_01() {
            assertNotNull(service);
        }
@Test void smoke_02() {
            assertNotNull(service);
        }
@Test void smoke_03() {
            assertNotNull(service);
        }
@Test void smoke_04() {
            assertNotNull(service);
        }
@Test void smoke_05() {
            assertNotNull(service);
        }
@Test void smoke_06() {
            assertNotNull(service);
        }
@Test void smoke_07() {
            assertNotNull(service);
        }
@Test void smoke_08() {
            assertNotNull(service);
        }
@Test void smoke_09() {
            assertNotNull(service);
        }
@Test void smoke_10() {
            assertNotNull(service);
        }
@Test void smoke_11() {
            assertNotNull(service);
        }
@Test void smoke_12() {
            assertNotNull(service);
        }
}
