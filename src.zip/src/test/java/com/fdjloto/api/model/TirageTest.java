
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class TirageTest {

@Test void defaultConstructor_createsInstance() {
                Tirage obj = new Tirage();
                assertNotNull(obj);
            }

@Test void smoke_02() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_03() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            Tirage obj = new Tirage();
            assertNotNull(obj);
        }
}
