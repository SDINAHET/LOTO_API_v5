
// package com.fdjloto.api.model;

// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class TicketGainTest {

// @Test void defaultConstructor_createsInstance() {
//                 TicketGain obj = new TicketGain();
//                 assertNotNull(obj);
//             }

// @Test void settersAndGetters_work() {
//                 TicketGain tg = new TicketGain();
//                 tg.setId("id");
//                 tg.setTicketId("t1");
//                 tg.setRank(9);
//                 tg.setGainAmount(2.5);
//                 tg.setCreatedAt(LocalDateTime.now().minusDays(1));
//                 tg.setUpdatedAt(LocalDateTime.now());
//                 assertEquals("id", tg.getId());
//                 assertEquals("t1", tg.getTicketId());
//                 assertEquals(9, tg.getRank());
//                 assertEquals(2.5, tg.getGainAmount());
//                 assertNotNull(tg.getCreatedAt());
//                 assertNotNull(tg.getUpdatedAt());
//             }

// @Test void smoke_03() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_16() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_17() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_18() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_19() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }

// @Test void smoke_20() {
//             TicketGain obj = new TicketGain();
//             assertNotNull(obj);
//         }
// }
