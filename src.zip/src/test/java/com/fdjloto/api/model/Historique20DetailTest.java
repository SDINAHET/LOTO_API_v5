
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class Historique20DetailTest {

@Test void defaultConstructor_createsInstance() {
                Historique20Detail obj = new Historique20Detail();
                assertNotNull(obj);
            }

@Test void smoke_02() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_03() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            Historique20Detail obj = new Historique20Detail();
            assertNotNull(obj);
        }
}
