
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class PredictionTirageModelTest {

@Test void defaultConstructor_createsInstance() {
                PredictionTirageModel obj = new PredictionTirageModel();
                assertNotNull(obj);
            }

@Test void smoke_02() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_03() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            PredictionTirageModel obj = new PredictionTirageModel();
            assertNotNull(obj);
        }
}
