
// package com.fdjloto.api.model;

// import com.fdjloto.api.model.*;
// import org.junit.jupiter.api.*;

// import java.time.*;

// import static org.junit.jupiter.api.Assertions.*;

// class RefreshTokenTest {

// @Test void defaultConstructor_createsInstance() {
//                 RefreshToken obj = new RefreshToken();
//                 assertNotNull(obj);
//             }

// @Test void settersAndGetters_work() {
//                 RefreshToken rt = new RefreshToken();
//                 rt.setId("id");
//                 rt.setUserId("u1");
//                 rt.setTokenHash("hash");
//                 rt.setCreatedAt(LocalDateTime.now().minusHours(2));
//                 rt.setExpiresAt(LocalDateTime.now().plusHours(1));
//                 rt.setRevokedAt(LocalDateTime.now());
//                 assertEquals("id", rt.getId());
//                 assertEquals("u1", rt.getUserId());
//                 assertEquals("hash", rt.getTokenHash());
//                 assertNotNull(rt.getCreatedAt());
//                 assertNotNull(rt.getExpiresAt());
//                 assertNotNull(rt.getRevokedAt());
//             }

// @Test void smoke_03() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_04() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_05() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_06() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_07() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_08() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_09() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_10() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_11() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_12() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_13() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_14() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_15() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_16() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_17() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_18() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_19() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }

// @Test void smoke_20() {
//             RefreshToken obj = new RefreshToken();
//             assertNotNull(obj);
//         }
// }
