
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class LoginRequestTest {

@Test void defaultConstructor_createsInstance() {
                LoginRequest obj = new LoginRequest();
                assertNotNull(obj);
            }

@Test void settersAndGetters_work() {
                LoginRequest lr = new LoginRequest();
                lr.setEmail("a@b.com");
                lr.setPassword("secret");
                assertEquals("a@b.com", lr.getEmail());
                assertEquals("secret", lr.getPassword());
            }

@Test void smoke_03() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            LoginRequest obj = new LoginRequest();
            assertNotNull(obj);
        }
}
