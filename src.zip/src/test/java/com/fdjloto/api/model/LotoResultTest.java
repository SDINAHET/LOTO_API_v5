
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class LotoResultTest {

@Test void defaultConstructor_createsInstance() {
                LotoResult obj = new LotoResult();
                assertNotNull(obj);
            }

@Test void smoke_02() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_03() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            LotoResult obj = new LotoResult();
            assertNotNull(obj);
        }
}
