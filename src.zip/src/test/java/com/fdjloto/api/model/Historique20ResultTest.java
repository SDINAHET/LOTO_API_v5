
package com.fdjloto.api.model;

import com.fdjloto.api.model.*;
import org.junit.jupiter.api.*;

import java.time.*;

import static org.junit.jupiter.api.Assertions.*;

class Historique20ResultTest {

@Test void defaultConstructor_createsInstance() {
                Historique20Result obj = new Historique20Result();
                assertNotNull(obj);
            }

@Test void smoke_02() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_03() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_04() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_05() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_06() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_07() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_08() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_09() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_10() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_11() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_12() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_13() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_14() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_15() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_16() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_17() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_18() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_19() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }

@Test void smoke_20() {
            Historique20Result obj = new Historique20Result();
            assertNotNull(obj);
        }
}
